public class LeapYear {
    public static boolean isLeapYear(int year) {

        int div4 = year % 4;
        int div100 = year % 100;
        int div400 = year % 400;

        if ((year < 1) || (year > 9999)) {
            return false;
        } else if (div4 != 0) {
            return false;
        } else if (div100 != 0) {
            return true;
        } else if (div400 == 0) {
            return true;
        } else {
            return false;
        }
    }

}