public class Main {
    public static void main(String[] args) {

        SpeedConverter.printConversion(SpeedConverter.toMilesPerHour(1.5));
        SpeedConverter.printConversion(SpeedConverter.toMilesPerHour(10.25));
        SpeedConverter.printConversion(SpeedConverter.toMilesPerHour(-5.6));

        MegaBytesConverter.printMegaBytesAndKiloBytes(2500);
        MegaBytesConverter.printMegaBytesAndKiloBytes(1024);
        MegaBytesConverter.printMegaBytesAndKiloBytes(5000);
    }
}
