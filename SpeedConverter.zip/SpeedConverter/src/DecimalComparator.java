public class DecimalComparator{

    public static boolean areEqualByThreeDecimalPlaces(double number1, double number2) {

        int result1 = (int) (number1 * 1000);
        int result2 = (int) (number2 * 1000);

        if (result1 == result2) {
            return true;
        }   else {
            return false;
        }
    }
}